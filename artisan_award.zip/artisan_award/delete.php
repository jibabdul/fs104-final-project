<?php
include 'config/config.php';
include 'config/db.php';

if(!isset($_GET['id'])){
    header("Location: " . SITE_URL);
} else {
    DB::delete("users", "users_id=%?", $_GET['id']); //table, condition, value in the condition in sequence
    header("Location: " . SITE_URL . "?success-delete=1");
}
?>