<?php
include 'config/config.php';
include 'config/functions.php';
include 'config/db.php';

// define variables and set to empty values
$nameError = $emailError = $websiteError = $genderError = "";
$name = $email = $website = $comment = $gender = "";

$hasPost = false;
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $hasPost = true;
    $comment = validateData($_POST['comment']);

    if(empty($_POST['name'])){
        $nameError = "Name is required.";
    }else{
        $name = validateData($_POST['name']);
        // The code below shows a simple way to check if the name field only contains letters and whitespaces.
        // If the value of the name field is not valid, then store an error message:
        if(!preg_match("/^[a-zA-Z ]*$/", $name)){ 
            $nameError = "Only letters and white spaces are allowed";
            $name = "";
        }
    }

    if(empty($_POST['email'])){
        $emailError = "Email is required.";
    }else{  
        $email = validateData($_POST['email']);      
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $emailError = "Invalid email format.";
            $email = "";
        }
    }

    if(empty($_POST['gender'])){
        $genderError = "Gender is required.";
    }else{
        $gender = validateData($_POST['gender']);
    }

    // The code below shows a way to check if a URL address syntax is valid (this regular expression also allows dashes in the URL).
    // If the URL address syntax is not valid, then store an error message:
    $website = validateData($_POST['website']);
    if(!empty($website)){
        if(!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $website)){
            $websiteError = "Website is invalid";
            $website = "";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/summernote/summernote-bs4.min.css">
     <!--Bootstrap CSS-->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
     <!--Google Fonts-->
     <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;0,700;1,400;1,700&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Serif:wght@700&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
     <!--Bootstrap Icon-->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
     <!-- Custom CSS -->
     <link href="css/main.css" rel="stylesheet">
    <title>Oriell Nominations</title>
</head>
<body>
    <!--Nav-Bar-->
    <div class="header" > <!--  Header Part code within it  --> 
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
          <a class="navbar-brand" href="overview.php"><img src="dist\img\logo-oriell.png" alt="" width="" height="" class="d-inline-block align-text-top"></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link" aria-current="page" href="overview.php">Overview</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="nominations.php">Nominations</a>
              </li>
            </ul>
            <form action="http://localhost:8888/artisan_award/login.php">
                <input type="submit" value="Login" />
            </form>
          </div>
        </div>
      </nav>
    </div>
  </div>
  <div>
</nav>
    <div class = "container"> <br>
    <h1>Nominate Your Works Today</h1><br>
<form class="row g-3" method="post" action="<?php echo htmlspecialchars('confirmation.php'); ?>">
  <div class="col-md-6">
    <label for="inputFname" class="form-label">First Name</label>
    <input type="text" class="form-control" id="inputEmail4" name="name" value="<?php echo $fname; ?>" required><span class="error"> <?php echo $nameError; ?></span>
  </div>
  <form class="row g-3">
  <div class="col-md-6">
    <label for="inputLname" class="form-label">Last Name</label>
    <input type="text" class="form-control" id="inputEmail4" name="lname" value="<?php echo $lname; ?>" required><span class="error"> <?php echo $lnameError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputPassword" class="form-label">Password</label>
    <input type="password" class="form-control" id="inputPassword4" name="password" value="<?php echo $password; ?>" required><span class="error"> <?php echo $passwordError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputPassword" class="form-label">Re-enter Password</label>
    <input type="password" class="form-control" id="inputPassword4" name="rpassword" value="<?php echo $rpassword; ?>" required><span class="error"> <?php echo $rpasswordError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputEmail" class="form-label">Email</label>
    <input type="email" class="form-control" id="inputEmail4" name="email" value="<?php echo $email; ?>" required><span class="error"> <?php echo $emailError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputWebsite" class="form-label">Website</label>
    <input type="url" class="form-control" id="inputEmail4" name="website" value="<?php echo $website; ?>" required><span class="error"> <?php echo $websiteError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputFacebook" class="form-label">Facebook</label>
    <input type="url" class="form-control" id="inputEmail4" name="facebook" value="<?php echo $facebook; ?>" required><span class="error"> <?php echo $facebookError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputAge" class="form-label">Age</label>
    <input type="text" class="form-control" id="inputEmail4" name="age" value="<?php echo $age; ?>" required><span class="error"> <?php echo $ageError; ?></span>
  </div>
  <div class="col-md-6">
    <label for="inputPhone" class="form-label">Phone</label>
    <input type="text" class="form-control" id="inputEmail4" name="phone" value="<?php echo $phone; ?>" required><span class="error"> <?php echo $phoneError; ?></span>
  </div>
  <div class="mb-3">
  <label for="formFile" class="form-label"><b>Upload your work nominations here</b></label>
  <input class="form-control" type="file" id="formFile" name="upload" value="<?php echo $upload; ?>" required><span class="error"> <?php echo $uploadError; ?></span>
</div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">Address</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St" name="address" value="<?php echo $address; ?>" required><span class="error"> <?php echo $addressError; ?></span>
  </div>
  <div class="col-12">
    <label for="inputAddress2" class="form-label">Address 2</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor" name="address2" value="<?php echo $address2; ?>" required><span class="error"> <?php echo $address2Error; ?></span>
  </div>
  <div class="col-md-2">
    <label for="inputPostal" class="form-label">Postal Code</label>
    <input type="text" class="form-control" id="inputZip" name="postal" value="<?php echo $postal; ?>" required><span class="error"> <?php echo $postalError; ?></span>
  </div>
  <div class="col-12">
  </div>
  <label for="inputGender" class="form-label">Gender</label>
  <div class="form-check">
  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" name="gender" value="<?php echo $gender; ?>" required><span class="error"> <?php echo $genderError; ?></span>
  <label class="form-check-label" for="flexRadioDefault1">Male</label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" name="gender" value="<?php echo $gender; ?>" required><span class="error"> <?php echo $genderError; ?></span>
  <label class="form-check-label" for="flexRadioDefault1">Female</label>
</div>
  <div class="col-12">
    <button type="submit" class="btn btn-primary">Submit</button>
  </div>
</form>
    </div>




    <!--jQuery-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <!--Bootstrap JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
    <!--Custom JS-->
    <script src="js/script-1.js"></script>  
</body>
</html>