<?php
include 'config/config.php';
include 'config/functions.php';
include 'config/db.php';

//if user is not logged in, then they may proceed
isNotLoggedIn();

$email = $password = $error = $loginSuccess = "";

if(isset($_POST['signIn'])){
  if(empty($_POST['email']) || empty($_POST['password'])){
    $error = "Please enter your email & password";
  }else{
    $email = validateData($_POST['email']);
    $password = validateData($_POST['password']);

    //validate if email is legit
    if(filter_var($email, FILTER_VALIDATE_EMAIL)) {
      //is a valid email address
      $userQuery = DB::query("SELECT * FROM users WHERE users_email=%s", $email);
      $userCount = DB::count();
      if($userCount == 1){ //user exist
        foreach($userQuery as $userResult){
          $dbId = $userResult['users_id'];
          $dbPassword = $userResult['users_password'];
        }
        //Verify if password matches
        if(password_verify($password, $dbPassword)){
          //if true - Login Success
          setcookie("userId", $dbId, time() + (86400 * 30)); // 86400 = 1 day - Storing cookie for 30 days
          setcookie("isLoggedIn", 1, time() + (86400 * 30)); // 86400 = 1 day - Storing cookie for 30 days
          $loginSuccess = 1;
        }else{
          //if false
          $error = "Please enter a valid email/password.";
        }
      }elseif($userCount > 1){
        $error = "Login error. Please contact website administrator.";
      }else{
        $error = "Please enter a valid email/password.";
      }
    } else {
      //is not a valid email address
      $error = "Please enter a valid email address";
      $email = "";
      $password = "";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/summernote/summernote-bs4.min.css">
     <!--Bootstrap CSS-->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
     <!--Google Fonts-->
     <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;0,700;1,400;1,700&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Serif:wght@700&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
     <!--Bootstrap Icon-->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
     <!-- Custom CSS -->
     <link href="css/main.css" rel="stylesheet">
</head>
<body class="hold-transition login-page" background="dist\img\Group 19128.png">
<div class="login-box">
  <div class="login-logo">
    <p><b>Let's get you started</b><p>
  </div>
  <!-- /.login-logo -->
  <div class="card">
    <div class="card-body login-card-body">
      <p class="login-box-msg">Sign in to <?php echo SITE_NAME; ?></p>

      <form action="<?php echo htmlspecialchars(SITE_URL . "login.php"); ?>" method="post">
        <div class="input-group mb-3">
          <input type="email" class="form-control" name="email" placeholder="Email">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-envelope"></span>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <input type="password" class="form-control" name="password" placeholder="Password">
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-lock"></span>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-8">
            <div class="icheck-primary">
              <input type="checkbox" id="remember">
              <label for="remember">
                Keep me logged in
              </label>
            </div>
          </div>
          <!-- /.col -->
          <div class="col-4">
            <button type="submit" name="signIn" class="btn btn-primary btn-block">Sign In</button>
          </div>
          <!-- /.col -->
        </div>
      </form>

      <br>

      <p class="mb-1">
        <a href="#">I forgot my password</a>
      </p>
      <p class="mb-0">
        <a href="<?php echo SITE_URL; ?>register.php" class="text-center">Sign up for a new membership</a>
      </p>
    </div>
    <!-- /.login-card-body -->
  </div>
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo SITE_URL; ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo SITE_URL; ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo SITE_URL; ?>dist/js/adminlte.min.js"></script>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script>
  <?php
  //if there is an error
  if($error != ""){
    echo 'swal("Opps...", "'. $error .'", "error");';
  }

  //if login is successful
  if($loginSuccess == 1){
    echo 'swal("Yay!", "Login Successfully!", "success", {
      buttons: false,
      timer: 1500,
    });';
    echo 'setTimeout(function() {
      window.location.href = "'. SITE_URL .'";
    }, 1500);';
  }

  //if logout is successful
  if($_GET['logoutSuccess'] == 1){
    echo 'swal("Logged Out.", "You have logged out successfully.", "success");';
  }
  ?>
</script>
</body>
</html>
