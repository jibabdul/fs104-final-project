<?php
//Validate form input before using it
function validateData($value){
    $value = trim($value); #Removes unnecessary characters (spaces, tab, newline)
    $value = stripslashes($value); #Removes backslahses (\) from the user input data
    $value = htmlspecialchars($value); #replace HTML characters like < and > with &lt; and &gt;
    return $value;
}

//Check cookies if user is logged in - used for Login page.
function isNotLoggedIn(){
    if(isset($_COOKIE['userId']) || isset($_COOKIE['isLoggedIn'])){
        header("Location: " . SITE_URL);
    }
}

function isLoggedIn(){
    if(!isset($_COOKIE['userId']) || !isset($_COOKIE['isLoggedIn'])){
        header("Location: " . SITE_URL . "login.php");
    }
}
?>