<?php
define("SITE_NAME", "Artisan Award Admin", true);
define("SITE_URL", "http://localhost:8888/artisan_award/", true);
?>