<?php
$inputPassword = "Password12!";
// hashing password
// echo password_hash($inputPassword, PASSWORD_DEFAULT);
// echo "<br>";

$dbPassword = '$2y$10$kulsm0WBdpCxLHwulJB7XejRZRaJXznHntWbEIulYQ1L784iSj2EW';

if(password_verify($inputPassword, $dbPassword)){ //use in login page / update password page
    echo "Password is correct.";
}else{
    echo "Password is incorrect.";
}
?>