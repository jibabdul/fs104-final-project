<?php
include 'config/config.php';
include 'config/db.php';
include 'config/functions.php';

$name = $email = $password = $cfmPassword = "";
$error = "";

if(isset($_POST['addUser'])){
    if(empty($_POST['name']) || empty($_POST['email']) || empty($_POST['password']) || empty($_POST['cfmPassword'])){
        $error = "Please fill up all required fields.";
    }else{
        $name = validateData($_POST['name']);
        $email = validateData($_POST['email']);
        $password = validateData($_POST['password']);
        $cfmPassword = validateData($_POST['cfmPassword']);
        if($password != $cfmPassword){
            $error = "Password mismatch. Please enter the same password.";
        }else{
            DB::insert("users", [
                'users_name' => strtolower($name),
                'users_email' => strtolower($email),
                'users_password' => password_hash($password, PASSWORD_DEFAULT)
            ]);
        
            header("Location: " . SITE_URL . "insert.php?insert-success=1");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Tempusdominus Bootstrap 4 -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- JQVMap -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/jqvmap/jqvmap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>dist/css/adminlte.min.css">
    <!-- overlayScrollbars -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/daterangepicker/daterangepicker.css">
    <!-- summernote -->
    <link rel="stylesheet" href="<?php echo SITE_URL; ?>plugins/summernote/summernote-bs4.min.css">
     <!--Bootstrap CSS-->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
     <!--Google Fonts-->
     <link rel="preconnect" href="https://fonts.gstatic.com">
     <link href="https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;0,700;1,400;1,700&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Serif:wght@700&family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
     <!--Bootstrap Icon-->
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
     <!-- Custom CSS -->
     <link href="css/main.css" rel="stylesheet">
    <title><?php echo SITE_NAME; ?> - Add New User</title>
    <style>
    .required{
        color: red;
    }
    </style>
</head>
<body>
    <?php
    if(isset($_GET['insert-success']) && $_GET['insert-success'] == 1){
        echo '<p>New user added successfully!</p>';
    }
    ?>
    <span class="required"><?php echo $error; ?></span>
    <form method="POST" action="<?php echo htmlspecialchars(SITE_URL . "insert.php"); ?>">
        Username: <input type="text" name="name" value="<?php echo $_POST['name']; ?>"><br>
        Email: <input type="email" name="email" value="<?php echo $_POST['email']; ?>"><br>
        Password: <input type="password" name="password"><br>
        Confirm Password: <input type="password" name="cfmPassword"><br>
        <input type="submit" value="Add New User" name="addUser">
    </form>
</body>
</html>