<?php
include 'config/config.php';
include 'config/functions.php';

//if user is logged in, they may proceed
isLoggedIn();

//unset all cookies
setcookie("userId", "", time() - 3600);
setcookie("isLoggedIn", "", time() - 3600);
header("Location: " . SITE_URL . "login.php?logoutSuccess=1");
?>